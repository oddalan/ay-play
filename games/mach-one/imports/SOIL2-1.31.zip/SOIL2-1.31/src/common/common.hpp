#include <string>

std::string ResourcePath(std::string fileName);
